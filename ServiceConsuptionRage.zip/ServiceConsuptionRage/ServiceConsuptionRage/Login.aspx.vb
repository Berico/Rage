﻿Imports System.IO
Imports System.Net
Imports System.ServiceModel
Imports System.Xml

Public Class Login
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim ServiceR As ServiceReferenceRage.testingSoapClient = New ServiceReferenceRage.testingSoapClient
        ServiceR.ClientCredentials.UserName.Password = "hajjwy2*uqyn1"

        Using (New OperationContextScope(ServiceR.InnerChannel))
            Try
                SoapAuthHeader.Create(ServiceR.ClientCredentials.UserName.Password)
                Dim Webrequest As WebRequest = WebRequest.Create("http://myrage.co.za/testing/testing.asmx")
                Webrequest.Method = "POST"
                Webrequest.ContentType = "text/xml; charset=utf-8"
                Dim branches As String = "<?xml version='1.0' encoding='utf-8'?>
<soap:Envelope xmlns:xsi='http://www.w3.org/2001/XMLSchema-instance' xmlns:xsd='http://www.w3.org/2001/XMLSchema' xmlns:soap='http://schemas.xmlsoap.org/soap/envelope/'>
  <soap:Body>
    <GetSomeStockcodesTesting xmlns='http://tempuri.org/' />
  </soap:Body>
</soap:Envelope>"

                Dim myStk() As ServiceReferenceRage.Stockcodes
                myStk = ServiceR.GetSomeStockcodesTesting()

                Dim ds As New DataSet()
                Dim layoutXml As XmlDocument = New XmlDocument()
                layoutXml.LoadXml(branches)
                Dim SR As StringReader = New StringReader(layoutXml.DocumentElement.OuterXml)
                ds.ReadXml(SR)


                Dim dt As DataTable = New DataTable()
                dt.Columns.Add("generated_code")
                dt.Columns.Add("master_code")
                dt.Columns.Add("category_1")
                dt.Columns.Add("category_2")
                dt.Columns.Add("category_3")
                dt.Columns.Add("sku_number")
                dt.Columns.Add("is_service_item")
                dt.Columns.Add("description")
                dt.Columns.Add("purchase_tax_group")
                dt.Columns.Add("sales_tax_group")
                dt.Columns.Add("supplier")
                dt.Columns.Add("suppliers_code")
                dt.Columns.Add("is_not_discountable")
                dt.Columns.Add("is_blocked")
                dt.Columns.Add("minimum_stock_level")
                dt.Columns.Add("item_size")
                dt.Columns.Add("item_colour")
                dt.Columns.Add("size_matrix")
                dt.Columns.Add("colour_matrix")
                dt.Columns.Add("cost_price")
                dt.Columns.Add("estimated_cost")
                dt.Columns.Add("selling_price_1")
                dt.Columns.Add("selling_price_2")
                dt.Columns.Add("selling_price_3")
                dt.Columns.Add("updated")
                dt.Columns.Add("created")
                dt.Columns.Add("qty_on_hand")

                Dim counter As Integer = myStk.Length
                Dim dr As DataRow

                If counter > 0 Then
                    Dim i As Integer = 0
                    While i < counter
                        dr = dt.NewRow()
                        'dt.Columns.Count()
                        dr("generated_code") = myStk(i).generated_code
                        dr("master_code") = myStk(i).master_code
                        dr("category_1") = myStk(i).category_1
                        dr("category_2") = myStk(i).category_2
                        dr("category_3") = myStk(i).category_3
                        dr("sku_number") = myStk(i).sku_number
                        dr("is_service_item") = myStk(i).is_service_item
                        dr("description") = myStk(i).description
                        dr("purchase_tax_group") = myStk(i).purchase_tax_group
                        dr("sales_tax_group") = myStk(i).sales_tax_group
                        dr("supplier") = myStk(i).supplier

                        dr("suppliers_code") = myStk(i).suppliers_code
                        dr("is_not_discountable") = myStk(i).is_not_discountable
                        dr("is_blocked") = myStk(i).is_blocked
                        dr("minimum_stock_level") = myStk(i).minimum_stock_level

                        dr("item_size") = myStk(i).item_size
                        dr("item_colour") = myStk(i).item_colour
                        dr("size_matrix") = myStk(i).size_matrix
                        dr("colour_matrix") = myStk(i).colour_matrix
                        dr("cost_price") = myStk(i).cost_price
                        dr("estimated_cost") = myStk(i).estimated_cost
                        dr("selling_price_1") = myStk(i).selling_price_1
                        dr("selling_price_2") = myStk(i).selling_price_2
                        dr("selling_price_3") = myStk(i).selling_price_3
                        dr("updated") = myStk(i).updated
                        dr("created") = myStk(i).created
                        dr("qty_on_hand") = myStk(i).qty_on_hand


                        dt.Rows.Add(dr)

                        i += 1
                    End While

                    GridView1.DataSource = dt
                    GridView1.DataBind()

                Else
                    Response.Write("no data")

                End If
            Catch ex As Exception
                Label1.Text = ex.Message

            Finally

            End Try

        End Using
    End Sub

End Class